package com.wu.stock.futuapi;

import com.futu.openapi.FTAPI;
import com.futu.openapi.FTAPI_Conn;
import com.futu.openapi.FTAPI_Conn_Trd;
import com.futu.openapi.FTSPI_Conn;
import com.futu.openapi.FTSPI_Trd;
import com.futu.openapi.pb.TrdGetAccList;

public class FundApi implements FTSPI_Trd, FTSPI_Conn {
    FTAPI_Conn_Trd trd = new FTAPI_Conn_Trd();

    public FundApi() {
        trd.setClientInfo("javaclient", 1);  //���ÿͻ�����Ϣ
        trd.setConnSpi(this);  //�������ӻص�
        trd.setTrdSpi(this);   //���ý��׻ص�
    }

    public void start() {
        trd.initConnect("127.0.0.1", (short)11111, false);
    }

    @Override
    public void onInitConnect(FTAPI_Conn client, long errCode, String desc)
    {
        System.out.printf("Trd onInitConnect: ret=%b desc=%s connID=%d\n", errCode, desc, client.getConnectID());
        if (errCode != 0)
            return;

        TrdGetAccList.C2S c2s = TrdGetAccList.C2S.newBuilder().setUserID(5972312)
                .build();
        TrdGetAccList.Request req = TrdGetAccList.Request.newBuilder().setC2S(c2s).build();
        int seqNo = trd.getAccList(req);
        System.out.printf("Send TrdGetAccList: %d\n", seqNo);
    }

    @Override
    public void onDisconnect(FTAPI_Conn client, long errCode) {
        System.out.printf("Trd onDisConnect: %d\n", errCode);
    }

    @Override
    public void onReply_GetAccList(FTAPI_Conn client, int nSerialNo, TrdGetAccList.Response rsp) {
        System.out.printf("Reply: TrdGetAccList: %d  %s\n", nSerialNo, rsp.toString());
        System.out.println(rsp.getS2C().getAccListList());
    }

    public static void main(String[] args) throws InterruptedException {
        FTAPI.init();
        FundApi trd = new FundApi();
        trd.start();
        Thread.sleep(1000 * 600);
    }
}