package com.wu.stock.futuapi;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.futu.openapi.FTAPI_Conn;
import com.futu.openapi.FTSPI_Qot;
import com.futu.openapi.pb.QotCommon;
import com.futu.openapi.pb.QotCommon.TimeShare;
import com.futu.openapi.pb.QotGetRT;
import com.wu.stock.entity.MinutePrice;
import com.wu.stock.util.GeneralUtils;

public class MinutePriceApi implements FTSPI_Qot {
    ConnFactory cf;
    List<TimeShare> rtListList;
    int tryTimes = 10;
    public static final Logger LOG = LogManager.getLogger(MinutePriceApi.class);
    @Override
    public void onReply_GetRT(FTAPI_Conn client, int nSerialNo, QotGetRT.Response rsp) {
    	if(rsp.getRetType()<0) {
    		LOG.error("MinutePriceApi.onReply_GetRT error!"+rsp.getRetMsg());
    	}
    	rtListList = rsp.getS2C().getRtListList();
    	cf.close();
    }



    public MinutePrice getMinutePrice(String code){
    	cf = ConnFactory.getConnect();
        cf.qot.setQotSpi(this);   //���ý��׻ص�
    	
        QotCommon.Security sec = QotCommon.Security.newBuilder()
                .setMarket(FutuConfig.MARKE_QOT)
                .setCode(code)
                .build();
        QotGetRT.C2S c2s = QotGetRT.C2S.newBuilder()
                .setSecurity(sec)
                .build();
        QotGetRT.Request req = QotGetRT.Request.newBuilder().setC2S(c2s).build();
        int seqNo = cf.qot.getRT(req);
        if (seqNo == 0) {
        	LOG.error("MinutePriceApi.getMinutePrice error!code="+code);
        	return null;
        }
        while(rtListList==null) {
        	GeneralUtils.sleep(200);
        	if (--tryTimes<=0) {
				return null;
			}
        }
        
        if (rtListList.size()<=0) {
			return null;
		}
		TimeShare timeShare = rtListList.get(rtListList.size()-1);
    	return new MinutePrice(code,timeShare.getPrice(),timeShare.getAvgPrice(),timeShare.getTime());
    }
    
    
}
