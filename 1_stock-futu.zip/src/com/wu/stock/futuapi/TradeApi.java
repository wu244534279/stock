package com.wu.stock.futuapi;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.futu.openapi.FTAPI_Conn;
import com.futu.openapi.FTSPI_Conn;
import com.futu.openapi.FTSPI_Trd;
import com.futu.openapi.pb.TrdCommon;
import com.futu.openapi.pb.TrdCommon.TimeInForce;
import com.futu.openapi.pb.TrdCommon.TrdSecMarket;
import com.futu.openapi.pb.TrdCommon.TrdSide;
import com.futu.openapi.pb.TrdPlaceOrder;
import com.futu.openapi.pb.TrdPlaceOrder.Response;
import com.wu.stock.entity.DealingOrder;
import com.wu.stock.util.GeneralUtils;

public class TradeApi implements FTSPI_Trd,FTSPI_Conn{
	TradFactory tf;
    int tryTimes = 10;
    int trdSide;
    double  qty;
    String code;
    double price;
    public static final Logger LOG = LogManager.getLogger(TradeApi.class);
    public TradeApi(String code,double price,int trdSide,double qty) {
    	tf=TradFactory.getConnect();
    	tf.trd.setTrdSpi(this);  
    	this.trdSide = trdSide;
    	this.qty=qty;
    	this.code=code;
    	this.price=price;
    }

    public void start() {
    	TrdCommon.TrdHeader header = TrdCommon.TrdHeader.newBuilder()
                .setAccID(FutuConfig.ACC_ID)
                .setTrdEnv(FutuConfig.ENV)
                .setTrdMarket(FutuConfig.MARKET_TRAD)
                .build();
        TrdPlaceOrder.C2S c2s = TrdPlaceOrder.C2S.newBuilder()
                .setPacketID(tf.trd.nextPacketID())
                .setHeader(header)
                .setOrderType(FutuConfig.ORDER_TYPE)
                .setCode(code)
                .setQty(qty)
                .setTimeInForce(TimeInForce.TimeInForce_DAY_VALUE)
                .setPrice(price).setTrdSide(trdSide).setSecMarket(TrdSecMarket.TrdSecMarket_US_VALUE)
            .build();
        TrdPlaceOrder.Request req = TrdPlaceOrder.Request.newBuilder().setC2S(c2s).build();
        int seqNo = tf.trd.placeOrder(req);
        if (seqNo == 0) {
        	LOG.error("TradeApi.start error!");
        }
    }
    
    
    boolean isOrderPlaced;
    
    @Override
    public void onReply_PlaceOrder(FTAPI_Conn client, int nSerialNo, Response rsp) {
    	if (rsp.getRetType()<0) {
    		LOG.error("TradeApi.onReply_PlaceOrder:"+rsp.getRetMsg());
		}
    	isOrderPlaced=true;
    	tf.close();
    }
    
    public void trade(DealingOrder order) {
		start();
        while (!this.isOrderPlaced) {
			GeneralUtils.sleep(100);
        	if (--tryTimes<=0) {
        		LOG.error("PositionApi.getPositions"+order);
        		tryTimes = 10;
				return;
			}
		}
    }
    
}

 