package com.wu.stock.futuapi;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.futu.openapi.FTAPI_Conn;
import com.futu.openapi.FTAPI_Conn_Qot;
import com.futu.openapi.FTSPI_Conn;
import com.futu.openapi.FTSPI_Qot;
import com.futu.openapi.pb.QotCommon;
import com.futu.openapi.pb.QotSub;
import com.futu.openapi.pb.QotSub.C2S.Builder;
import com.wu.stock.FutuBootStrap;
import com.wu.stock.config.MetaConfig;
import com.wu.stock.util.GeneralUtils;

public class ConnFactory implements FTSPI_Qot, FTSPI_Conn {
	
    public FTAPI_Conn_Qot qot = new FTAPI_Conn_Qot();
    public static final Logger LOG = LogManager.getLogger(ConnFactory.class);
    private volatile boolean isUsing;
    private volatile boolean isInit;
    private ConnFactory() {
        qot.setClientInfo("javaclient", 1);  //���ÿͻ�����Ϣ
        qot.setConnSpi(this);  //�������ӻص�
        qot.setQotSpi(this);   //���ý��׻ص�
    }

    public void start() {
        qot.initConnect("127.0.0.1", (short)11111, true);
    }

    @Override
    public void onInitConnect(FTAPI_Conn client, long errCode, String desc)
    {
        if (errCode != 0) {
        	LOG.error("Qot onInitConnect error:");
            return;
        }
        sub();
    }
    
    public void sub() {
    	 Builder c2s = QotSub.C2S.newBuilder()
                 .addSubTypeList(QotCommon.SubType.SubType_Basic_VALUE)
                 //.addSubTypeList(QotCommon.SubType.SubType_RT_VALUE)
                 .setIsSubOrUnSub(true);
    	 
         
         Collection<String> codes = MetaConfig.configMap.keySet();
         for (String co : codes) {
             QotCommon.Security sec = QotCommon.Security.newBuilder()
                     .setMarket(FutuConfig.MARKE_QOT)
                     .setCode(co)
                     .build();
             c2s.addSecurityList(sec);
 		}
         QotSub.Request req = QotSub.Request.newBuilder().setC2S(c2s.build()).build();
         int seqNo = qot.sub(req);
         System.out.printf("Send QotSub: %d\n", seqNo);
    }

    @Override
    public void onDisconnect(FTAPI_Conn client, long errCode) {
        System.out.printf("Qot onDisConnect: %d\n", errCode);
    }

    @Override
    public void onReply_Sub(FTAPI_Conn client, int nSerialNo, QotSub.Response rsp) {
        System.out.printf("Reply: QotSub: %d  %s\n", nSerialNo, rsp.getRetMsg());
        isInit=true;
    }

    private static  Set<ConnFactory> cons = new HashSet<>();

    public synchronized static void initConnect() {
    	for (ConnFactory connFactory : cons) {
			connFactory.qot.close();
		}
    	cons.clear();
    	GeneralUtils.sleep(1000);
    	for (int i=0;i<1;i++) {
        	ConnFactory connFactory = new ConnFactory();
        	connFactory.start();
        	while (!connFactory.isInit) {
				GeneralUtils.sleep(100);
			}
        	cons.add(connFactory);
		}
    	

    }
    
    public static synchronized ConnFactory getConnect() {
    	while(true) {
	    	for (ConnFactory con : cons) {
				if(!con.isUsing) {
					con.isUsing=true;
					return con;
				}
			}
	    	GeneralUtils.sleep(100);
    	}
    }
    
    public void close() {
    	this.isUsing=false;
    }
    
}