package com.wu.stock.futuapi;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.futu.openapi.FTAPI_Conn;
import com.futu.openapi.FTSPI_Trd;
import com.futu.openapi.pb.TrdCommon;
import com.futu.openapi.pb.TrdCommon.AccCashInfo;
import com.futu.openapi.pb.TrdCommon.Funds;
import com.futu.openapi.pb.TrdGetFunds;
import com.wu.stock.entity.Account;
import com.wu.stock.util.GeneralUtils;

public class AccountApi implements FTSPI_Trd {
    TradFactory tf;
    int tryTimes = 10;
    Funds funds;
    public static final Logger LOG = LogManager.getLogger(AccountApi.class);
    @Override
    public void onReply_GetFunds(FTAPI_Conn client, int nSerialNo, TrdGetFunds.Response rsp) {
    	if(rsp.getRetType()<0) {
    		LOG.error("AccountApi.onReply_GetFunds error!"+rsp.getRetMsg());
    	}
    	funds = rsp.getS2C().getFunds();
    	tf.close();
    }

    public Account getAccount(){
    	tf = TradFactory.getConnect();
        tf.trd.setTrdSpi(this);   //���ý��׻ص�
        
        TrdCommon.TrdHeader header = TrdCommon.TrdHeader.newBuilder()
                .setAccID(FutuConfig.ACC_ID)
                .setTrdEnv(FutuConfig.ENV)
                .setTrdMarket(FutuConfig.MARKET_TRAD)
                .build();
        TrdGetFunds.C2S c2s = TrdGetFunds.C2S.newBuilder()
                .setHeader(header)
                .build();
        TrdGetFunds.Request req = TrdGetFunds.Request.newBuilder().setC2S(c2s).build();
        int seqNo = tf.trd.getFunds(req);
        if (seqNo == 0) {
        	LOG.error("AccountApi.getAccount error!");
        	return null;
        }
        while(funds==null) {
        	GeneralUtils.sleep(200);
        	if (--tryTimes<=0) {
        		LOG.error("AccountApi.getAccount error! and retinit conn");
				ConnFactory.initConnect();
				return null;
			}
        }
			System.out.println(funds);
        
        return new Account("", funds.getCash());
    }
    
    public static void main(String[] args) {
    	TradFactory.initConnect();
    	System.out.println(new AccountApi().getAccount());
	}
    
    
}
