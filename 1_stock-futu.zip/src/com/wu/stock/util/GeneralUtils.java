package com.wu.stock.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Map;

public class GeneralUtils {
	public static void sleep(long millSeconds) {
		try {
			Thread.sleep(millSeconds);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public static boolean isEmpty(Collection col) {
		return col==null || col.size()==0;
	}
	
	public static boolean isEmpty(Map map) {
		return map==null || map.size()==0;
	}
	
	public static long toLong(String date) {
		SimpleDateFormat formatter = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss");
		try {
			return formatter.parse(date).getTime();
		} catch (ParseException e) {
		}
		return 0;
	}

	public static boolean isEmpty(String line) {
		return line==null || line.trim()=="";
	}
	
	public static String toDateTimeString(String ymd,String hmis) {
		String y = ymd.substring(0,4);
		String m = ymd.substring(4,6);
		String d = ymd.substring(6,8);
		String h = hmis.substring(0,2);
		String mi = hmis.substring(2,4);
		String s = hmis.substring(4,6);
		return (y+"-"+m+"-"+d+" "+h+":"+mi+":"+s);
	}
	
}
