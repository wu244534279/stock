package com.wu.stock.util;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LogUtils {
	public static final Logger LOG = LogManager.getLogger(LogUtils.class);
	public static void important(String msg) {
		LOG.info(msg);
	}
}
