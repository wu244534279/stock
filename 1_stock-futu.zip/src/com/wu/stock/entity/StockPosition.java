package com.wu.stock.entity;

/**
 * �ֲ�
 * @author Administrator
 *
 */
public class StockPosition {
	private String code;
	private double qty;
	private double costPrice;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public double getQty() {
		return qty;
	}
	public void setQty(double qty) {
		this.qty = qty;
	}
	public double getCostPrice() {
		return costPrice;
	}
	public void setCostPrice(double costPrice) {
		this.costPrice = costPrice;
	}
	public StockPosition(String code, double qty, double costPrice) {
		super();
		this.code = code;
		this.qty = qty;
		this.costPrice = costPrice;
	}
	@Override
	public String toString() {
		return "StockPosition [code=" + code + ", qty=" + qty + ", costPrice=" + costPrice + "]";
	}
}