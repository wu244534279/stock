package com.wu.stock.entity;

/**
 * �˻�
 * @author Administrator
 *
 */
public class Account {
	private String accId;
	private double balance;
	
	
	public Account(String accId, double balance) {
		super();
		this.accId = accId;
		this.balance = balance;
	}
	public String getAccId() {
		return accId;
	}
	public void setAccId(String accId) {
		this.accId = accId;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Account [accId=" + accId + ", balance=" + balance + "]";
	}
	
	
}
