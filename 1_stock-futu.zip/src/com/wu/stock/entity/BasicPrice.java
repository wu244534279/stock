package com.wu.stock.entity;

/**
 * ʵʱ����
 * @author Administrator
 *
 */
public class BasicPrice {
	private String code;
	private double curPrice;
	private double lastClosePrice;
	private long volumn;
	
	
	
	public BasicPrice(String code, double curPrice, double lastClosePrice,long volumn) {
		super();
		this.code = code;
		this.curPrice = curPrice;
		this.lastClosePrice = lastClosePrice;
		this.volumn=volumn;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public double getCurPrice() {
		return curPrice;
	}
	public void setCurPrice(double curPrice) {
		this.curPrice = curPrice;
	}
	public double getLastClosePrice() {
		return lastClosePrice;
	}
	public void setLastClosePrice(double lastClosePrice) {
		this.lastClosePrice = lastClosePrice;
	}
	
	public long getVolumn() {
		return volumn;
	}
	public void setVolumn(long volumn) {
		this.volumn = volumn;
	}
	@Override
	public String toString() {
		return "BQ [code=" + code + ", cp=" + curPrice + ", lcp=" + lastClosePrice
				+ ", vol=" + volumn + "]";
	}
	
	
}
