package com.wu.stock.config;

import java.util.HashMap;
import java.util.Map;

/**
 * Ԫ��������
 * @author Administrator
 *
 */
public class MetaConfig {

	private String code;

	//��ǰ�۵���ƽ����xxxʱ������
	private double buyPointAvgLow=-0.01;
	
	//��ǰ�۵��ڳֲֳɱ�xxxʱ������
	private double buyPointCostLow=-0.03;
	
	
	//��ǰ�۸��ڳֲֳɱ�xxxʱ������
	private double sellPointCostHight=0.02;
	
	public MetaConfig() {

	}
	
	public MetaConfig(String code, double buyPointAvgLow, double buyPointCostLow, double sellPointCostHight) {
		super();
		this.code = code;
		this.buyPointAvgLow = buyPointAvgLow;
		this.buyPointCostLow = buyPointCostLow;
		this.sellPointCostHight = sellPointCostHight;
	}


	public static Map<String,MetaConfig> configMap = new HashMap<>();
	static {
		configMap.put("QCOM", new MetaConfig("QCOM", -0.01, -0.03, 0.02));
	}
	
	
	public static MetaConfig getConfig(String code) {
		return configMap.getOrDefault(code,new MetaConfig());
	}


	public String getCode() {
		return code;
	}


	public void setCode(String code) {
		this.code = code;
	}


	public double getBuyPointAvgLow() {
		return buyPointAvgLow;
	}


	public void setBuyPointAvgLow(double buyPointAvgLow) {
		this.buyPointAvgLow = buyPointAvgLow;
	}


	public double getBuyPointCostLow() {
		return buyPointCostLow;
	}


	public void setBuyPointCostLow(double buyPointCostLow) {
		this.buyPointCostLow = buyPointCostLow;
	}


	public double getSellPointCostHight() {
		return sellPointCostHight;
	}


	public void setSellPointCostHight(double sellPointCostHight) {
		this.sellPointCostHight = sellPointCostHight;
	}

	@Override
	public String toString() {
		return "MetaConfig [code=" + code + ", buyPointAvgLow=" + buyPointAvgLow + ", buyPointCostLow="
				+ buyPointCostLow + ", sellPointCostHight=" + sellPointCostHight + "]";
	}
	
}
