package com.wu.stock.config;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.wu.stock.entity.BasicPrice;

public class CommonStatus {
	
	/**
	 * ����Ҫ����
	 */
	public volatile static Set<String> CODE_BUYING = new HashSet<>();
	
	
	public volatile static Map<String, BasicPrice> ABLE_TO_BUY = new HashMap<String, BasicPrice>();
	public volatile static Map<String, BasicPrice> ABLE_TO_SELL = new HashMap<String, BasicPrice>();
}
