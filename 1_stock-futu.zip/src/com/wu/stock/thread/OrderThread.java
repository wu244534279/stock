package com.wu.stock.thread;

import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.wu.stock.config.CommonStatus;
import com.wu.stock.dao.futu.DataGather;
import com.wu.stock.dao.futu.Trader;
import com.wu.stock.entity.DealingOrder;
import com.wu.stock.util.GeneralUtils;

public class OrderThread extends Thread{
	public static final int ORDER_EXPIRE_MINUTES = 3;
	public static final Logger LOG = LogManager.getLogger(OrderThread.class);
	@Override
	public void run() {
		while(true) {
			try {
				LOG.debug("OrderThread running....!"+new Date());
				if(!DataGather.isTradeTime() && !DataGather.isOnlySellTime()) {
					LOG.info("OrderThread current time is not trade time!"+new Date());
					GeneralUtils.sleep(60000);
					continue;
				}
				
				List<DealingOrder> orders = DataGather.getOrders();
				if(GeneralUtils.isEmpty(orders)) {
					LOG.info("OrderThread running,no dealing orders");
					GeneralUtils.sleep(60000);
					continue;
				}

				for (DealingOrder order : orders) {
					if(expire(order)) {
						LOG.info("--------OrderThread order is expire,will cancel it==>"+order);
						Trader.cancel(order);
						CommonStatus.ABLE_TO_SELL.remove(order.getCode());
					}else {
						LOG.debug("OrderThread order is not expire==>"+order);
					}
				}
				GeneralUtils.sleep(30000);
				
			} catch (Exception e) {
				LOG.error("OrderThread error",e);
			}
				
		}
	}

	private boolean expire(DealingOrder order) {
		
		long cts = GeneralUtils.toLong(order.getCreateTime())+12*60*60*1000;
		long minutesDif = (System.currentTimeMillis() - cts) / (1000 * 60);
		if (minutesDif>3) {
			LOG.info("cancel time out order! --"+order);
			return true;
		}
	
		return false;
	}
	
	public static void main(String[] args) {
	}
	
}
