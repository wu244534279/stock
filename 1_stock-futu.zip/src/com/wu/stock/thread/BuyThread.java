package com.wu.stock.thread;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.wu.stock.config.CommonStatus;
import com.wu.stock.config.MetaConfig;
import com.wu.stock.dao.futu.DataGather;
import com.wu.stock.dao.futu.Trader;
import com.wu.stock.entity.BasicPrice;
import com.wu.stock.entity.DealingOrder;
import com.wu.stock.entity.StockPosition;
import com.wu.stock.util.GeneralUtils;

/**
 * ǰ�ù����߳�
 * @author Administrator
 *
 */
public class BuyThread extends Thread{
	public static final Logger LOG = LogManager.getLogger(BuyThread.class);
	
	@Override
	public void run() {
		while(true) {
			try {
				LOG.debug("BuyThread running....!"+new Date());
				if(!DataGather.isTradeTime()) {
					LOG.info("BuyPrevThread current time is not buy time!"+new Date());
					CommonStatus.CODE_BUYING.clear();
					GeneralUtils.sleep(60000);
					continue;
				}
				
				List<BasicPrice> bqs = DataGather.getBasicPrices();
				if(GeneralUtils.isEmpty(bqs)) {
					LOG.info("BuyPrevThread getBasicPrices is null!");
					GeneralUtils.sleep(30000);
				}
				
				LOG.info("BuyThread,there are some basic price to  process==>"+bqs.size());
				
				Map<String, StockPosition> posm = DataGather.getPositionsMap();
				List<DealingOrder> orders = DataGather.getOrders();
				
				for (BasicPrice bq:bqs) {
					if (bq.getVolumn()<100000) {
						LOG.info("too small volumn,not buy.."+bq);
						continue;
					}
					
					if (inOrderIng(bq,orders)) {
						LOG.info("in ordering,not buy.."+bq);
						continue;
					}
					
					LOG.debug("BuyPrevThread getBasicPrice"+bq);
					addPostion(bq,posm);
					
					BasicPrice ableToBuyBQ = CommonStatus.ABLE_TO_BUY.get(bq.getCode());
					if (ableToBuyBQ==null && ableFirstToBuy(bq,posm)) {
						CommonStatus.ABLE_TO_BUY.put(bq.getCode(), bq);
					}
					
					if(ableToBuyBQ!=null){
						firstToBuy(bq, posm);
					}
					
				}
			} catch (Exception e) {
				LOG.error("BuyThread error",e);
			}
		}
	}
	
	private boolean inOrderIng(BasicPrice bq, List<DealingOrder> orders) {
		if (GeneralUtils.isEmpty(orders)) {
			return false;
		}
		
		for (DealingOrder dealingOrder : orders) {
			if (bq.getCode().equalsIgnoreCase(dealingOrder.getCode())) {
				return true;
			}
		}
		return false;
	}

	/**
	 * �¹���
	 */
	public boolean ableFirstToBuy(BasicPrice bq,Map<String, StockPosition> posm) {
		if(CommonStatus.CODE_BUYING.contains(bq.getCode())) {
			LOG.debug("The code "+bq.getCode()+" is already in the set of able to buy!");
			return false;
		}
		
		if(!GeneralUtils.isEmpty(posm) && posm.containsKey(bq.getCode())) {
			LOG.debug("The code "+bq.getCode()+" is already in position!");
			return false;
		}
		
		return judgeAbleToFirstBuy(bq);
	}

	public void firstToBuy(BasicPrice bq,Map<String, StockPosition> posm){
		if(CommonStatus.CODE_BUYING.contains(bq.getCode())) {
			LOG.debug("The code "+bq.getCode()+" is already in the set of able to buy!");
			return;
		}
		
		if(!GeneralUtils.isEmpty(posm) && posm.containsKey(bq.getCode())) {
			LOG.debug("The code "+bq.getCode()+" is already in position!");
			return;
		}
		
		BasicPrice lastPrice = CommonStatus.ABLE_TO_BUY.get(bq.getCode());
		
		if (lastPrice.getCurPrice()>=bq.getCurPrice()*0.999) {
			if (lastPrice.getCurPrice()>bq.getCurPrice()) {
				CommonStatus.ABLE_TO_BUY.put(bq.getCode(), bq);
			}
			return;
		}
		
		int buyQty = (int) (1000/bq.getCurPrice());
		buyQty = buyQty<=1?1:buyQty;
		DealingOrder buyOrder = new DealingOrder(bq.getCode(),bq.getCurPrice(),buyQty,null);
		Trader.buy(buyOrder);
		CommonStatus.CODE_BUYING.add(bq.getCode());
	}

	/**
	 * ����
	 */
	public void addPostion(BasicPrice bq,Map<String, StockPosition> posm ) {
		
		if(CommonStatus.CODE_BUYING.contains(bq.getCode())) {
			LOG.debug("addPostion-- The code "+bq.getCode()+" is already in the set of ordering!");
			return;
		}
		
		StockPosition pos = posm.get(bq.getCode());
		if(pos==null) {
			LOG.debug("No position and no need to add Position!==>"+bq.getCode());
			return;			
		}
		MetaConfig config = MetaConfig.getConfig(bq.getCode());
		if((pos.getCostPrice()*(1.0d+config.getBuyPointCostLow()))>=bq.getCurPrice()) {
			int buyQty = (int) (1000/bq.getCurPrice());
			buyQty = buyQty<=1?1:buyQty;
			DealingOrder buyOrder = new DealingOrder(bq.getCode(),bq.getCurPrice(),buyQty,null);
			Trader.buy(buyOrder);
			LOG.info("++++++ Adding position code=>"+bq.getCode()+",price=>"+bq.getCurPrice()+",qty=>"+buyQty);
			CommonStatus.CODE_BUYING.add(bq.getCode());
		}
		
	}
	
	private boolean judgeAbleToFirstBuy(BasicPrice bq) {
		MetaConfig config = MetaConfig.getConfig(bq.getCode());
		
		if((bq.getLastClosePrice()*(1.0d+config.getBuyPointAvgLow()))>=bq.getCurPrice()) {
			LOG.info("++++++++ First buy =>"+bq);
			return true;
		}
		
		LOG.debug("---------Not buy "+bq);
		
		return false;
	}	
	
	
	public static void main(String[] args) {
		System.out.println(200/150);
	}
}
