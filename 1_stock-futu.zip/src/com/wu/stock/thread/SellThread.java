package com.wu.stock.thread;

import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.wu.stock.config.CommonStatus;
import com.wu.stock.config.MetaConfig;
import com.wu.stock.dao.futu.DataGather;
import com.wu.stock.dao.futu.Trader;
import com.wu.stock.entity.BasicPrice;
import com.wu.stock.entity.DealingOrder;
import com.wu.stock.entity.StockPosition;
import com.wu.stock.util.GeneralUtils;

public class SellThread extends Thread{
	
	public static final Logger LOG = LogManager.getLogger(SellThread.class);
	@Override
	public void run() {
		while(true) {
			
			try {
				LOG.debug("SellThread running....!"+new Date());
				
				if(DataGather.isOnlySellTime()) {
					sellOnly();
					GeneralUtils.sleep(1000);
					continue;
				}
				
				if(!DataGather.isTradeTime()) {
					LOG.info("SellThread current time is not sell time!"+new Date());
					GeneralUtils.sleep(60000);
					continue;
				}
				
				List<StockPosition> positions = DataGather.getPositions();
				if(GeneralUtils.isEmpty(positions)) {
					LOG.info("SellThread running,no positions");
					GeneralUtils.sleep(60000);
					continue;
				}
				
				List<DealingOrder> orders = DataGather.getOrders();
				
				for (StockPosition pos : positions) {
					if (pos.getQty()<=0) {
						LOG.debug("The pos's qty is zero!"+pos);
						continue;
					}
					
					if(posOnOrdering(pos,orders)) {
						LOG.debug("The pos is in ordering,will not sell again!"+pos.getCode());
						continue;
					}
					
					BasicPrice basicPrice = DataGather.getBasicPrice(pos.getCode());
					if(basicPrice==null) {
						LOG.error("SellThread running,get basicPrice error!"+pos.getCode());
						continue;
					}
					
					MetaConfig config = MetaConfig.getConfig(pos.getCode());
					LOG.info("SellThread  pos:"+pos+"-cur price=>"+basicPrice.getCurPrice());
					
					BasicPrice ableToSell = CommonStatus.ABLE_TO_SELL.get(pos.getCode());
					
					if(ableToSell==null && basicPrice.getCurPrice()>= (pos.getCostPrice()*(1.0d+config.getSellPointCostHight()))) {
						CommonStatus.ABLE_TO_SELL.put(pos.getCode(), basicPrice);
					}
					if (ableToSell!=null) {
						
						if (ableToSell.getCurPrice()*0.998>basicPrice.getCurPrice()) {
							DealingOrder order= new DealingOrder(pos.getCode(),basicPrice.getCurPrice(),pos.getQty(),null);
							Trader.sell(order);
						}else {
							if (ableToSell.getCurPrice()<basicPrice.getCurPrice()) {
								CommonStatus.ABLE_TO_SELL.put(pos.getCode(), basicPrice);
							}
						}
					}
					
				}
				
				GeneralUtils.sleep(10000);
			} catch (Exception e) {
				LOG.error("SellThread error",e);
			}
		}
	}

	private void sellOnly() {

		LOG.info("---SellThread current time is only sell time!"+new Date());
		List<StockPosition> poss = DataGather.getPositions();
		if (GeneralUtils.isEmpty(poss)) {
			GeneralUtils.sleep(60000);
			return;
		}
		
		List<DealingOrder> orders = DataGather.getOrders();
		for (StockPosition pos : poss) {
			if(posOnOrdering(pos,orders)) {
				LOG.debug("The pos is in ordering,will not sell again!"+pos.getCode());
				continue;
			}
		
			BasicPrice basicPrice = DataGather.getBasicPrice(pos.getCode());
			if(basicPrice==null) {
				LOG.error("SellThread running,get basicPrice error!"+pos.getCode());
				continue;
			}
			
			if (pos.getCostPrice()<basicPrice.getCurPrice()) {
				DealingOrder order= new DealingOrder(pos.getCode(),basicPrice.getCurPrice(),pos.getQty(),null);
				Trader.sell(order);
			}
		}
	}

	private boolean posOnOrdering(StockPosition pos, List<DealingOrder> orders) {
		if(GeneralUtils.isEmpty(orders)) {
			return false;
		}
		
		for (DealingOrder dealingOrder : orders) {
			if(dealingOrder.getCode().equals(pos.getCode())) {
				return true;
			}
		}
		return false;
	}
}
