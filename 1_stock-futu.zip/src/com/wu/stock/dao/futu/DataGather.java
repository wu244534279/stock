package com.wu.stock.dao.futu;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;

import com.futu.openapi.FTAPI;
import com.wu.stock.entity.Account;
import com.wu.stock.entity.BasicPrice;
import com.wu.stock.entity.MinutePrice;
import com.wu.stock.entity.DealingOrder;
import com.wu.stock.entity.StockPosition;
import com.wu.stock.futuapi.AccountApi;
import com.wu.stock.futuapi.BasicPriceApi;
import com.wu.stock.futuapi.ConnFactory;
import com.wu.stock.futuapi.MinutePriceApi;
import com.wu.stock.futuapi.OrderApi;
import com.wu.stock.futuapi.PositionApi;
import com.wu.stock.futuapi.TradFactory;
import com.wu.stock.util.GeneralUtils;

public class DataGather {
	
	public static List<BasicPrice> getBasicPrices(){
		return new BasicPriceApi().getAllBqs();
	}
	
	public static BasicPrice getBasicPrice(String code){
		return new BasicPriceApi().getBqs(code);
	}
	
	public static void main2(String[] args) {
		FTAPI.init();
		ConnFactory.initConnect();
		TradFactory.initConnect();
		//System.out.println(getMinutePrice("QCOM"));
		System.out.println(getBasicPrice("QCOM"));
	}
	
	
	public static MinutePrice getMinutePrice(String code){
		return new MinutePriceApi().getMinutePrice(code);
	}
	
	public static List<StockPosition> getPositions(){
		return new PositionApi().getPositions();
	}
	
	public static Map<String,StockPosition> getPositionsMap(){
		Map<String,StockPosition> map = new HashMap<String, StockPosition>();
		List<StockPosition> pos = getPositions();
		if (GeneralUtils.isEmpty(pos)) {
			return map;
		}
		for (StockPosition po:pos) {
			map.put(po.getCode(), po);
		}
		return map;
	}
	
	public static List<DealingOrder> getOrders(){
		List<DealingOrder> orders = new OrderApi().getOrders(true);
		return orders;
	}
	
	public static Account getAccount() {
		return new AccountApi().getAccount();
	}
	
	public static boolean isTradeTime() {
		if (DateTime.now().withHourOfDay(21).withMinuteOfHour(35).isBeforeNow() || DateTime.now().withHourOfDay(3).withMinuteOfHour(50).isAfterNow()) {
			return true;
		}
		return false;
	}

	public static boolean isOnlySellTime() {
		if (DateTime.now().withHourOfDay(21).withMinuteOfHour(30).isBeforeNow() 
				&& DateTime.now().withHourOfDay(21).withMinuteOfHour(35).isAfterNow()) {
			return true;
		}
		
		if (DateTime.now().withHourOfDay(3).withMinuteOfHour(50).isBeforeNow() 
				&& DateTime.now().withHourOfDay(4).withMinuteOfHour(0).isAfterNow()) {
			return true;
		}		
		return false;
	}
	
	
	public static void main(String[] args) {
		System.out.println(!DataGather.isTradeTime() && !DataGather.isOnlySellTime());
	}
}
