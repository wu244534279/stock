package com.wu.stock.dao.futu;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.futu.openapi.pb.TrdCommon.TrdSide;
import com.wu.stock.entity.DealingOrder;
import com.wu.stock.futuapi.OrderApi;
import com.wu.stock.futuapi.TradFactory;
import com.wu.stock.futuapi.TradeApi;

public class Trader {
	public static final Logger LOG = LogManager.getLogger(Trader.class);
	public static void buy(DealingOrder order) {
		LOG.warn("+++++++++++buy order "+order);
		new TradeApi(order.getCode(),order.getPrice(), TrdSide.TrdSide_Buy_VALUE,order.getQty()).trade(order);
	}
	
	public static void sell(DealingOrder order) {
		LOG.warn("************sell order "+order);
		new TradeApi(order.getCode(),order.getPrice(), TrdSide.TrdSide_Sell_VALUE,order.getQty()).trade(order);
	}
	
	public static void cancel(DealingOrder order) {
		LOG.warn("------------cancel order "+order);
		new OrderApi().cancelOrder(order);
	}
	
	public static void main(String[] args) {
		TradFactory.initConnect();
		buy(new DealingOrder("ORCL", 100, 100, null));
	}
}
