package com.wu.stock.util;

import java.io.IOException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.X509TrustManager;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import com.alibaba.fastjson.JSONObject;


public class HttpUtils {
	

	  /**
     * post�����Լ�������json
     *
     * @param url
     * @param jsonParams
     * @return
     */
    public static JSONObject post(String url, JSONObject jsonParams) {
        CloseableHttpClient httpClient = HttpClients.createDefault();
        JSONObject jsonObject = null;
        HttpPost httpPost = new HttpPost(url);
        RequestConfig requestConfig = RequestConfig.custom().
                setConnectTimeout(180 * 1000).setConnectionRequestTimeout(180 * 1000)
                .setSocketTimeout(180 * 1000).setRedirectsEnabled(true).build();
        httpPost.setConfig(requestConfig);
        httpPost.setHeader("Content-Type", "application/json");
        try {
            httpPost.setEntity(new StringEntity(jsonParams.toJSONString(), ContentType.create("application/json", "utf-8")));
            LogUtils.debug("request parameters" + EntityUtils.toString(httpPost.getEntity()));
            LogUtils.debug("httpPost:" + httpPost);
            HttpResponse response = httpClient.execute(httpPost);
            if (response != null && response.getStatusLine().getStatusCode() == 200) {
                String result = EntityUtils.toString(response.getEntity());
                LogUtils.debug("result:" + result);
                jsonObject = JSONObject.parseObject(result);
                return jsonObject;
            }
        } catch (Exception e) {
        	LogUtils.error("HttpUtils.post error!"+e.getMessage() );
        } finally {
            if (null != httpClient) {
                try {
                    httpClient.close();
                } catch (Exception e) {
                	LogUtils.error("HttpUtils.post error!"+e.getMessage() );
                }
            }
        }
        return jsonObject;
    }

    
    static X509TrustManager trustManager = new X509TrustManager(){
    	@Override
    	public void checkClientTrusted(X509Certificate[] arg0, String arg1)
    	throws CertificateException {
    	}
    	@Override
    	public void checkServerTrusted(X509Certificate[] arg0, String arg1)
    	throws CertificateException {
    	}
    	@Override
    	public X509Certificate[] getAcceptedIssuers() {
    	return null;
    	}
    	};
    
    public static String get(String url) {
    	HttpGet httpGet = new HttpGet(url);
    	CloseableHttpResponse response = null;
    	CloseableHttpClient client =null;
    	try {
        	 client = HttpClients.createDefault();
        	
    		response = client.execute(httpGet);

			HttpEntity re = response.getEntity();
			LogUtils.debug("��Ӧ״̬Ϊ:" + response.getStatusLine());
			return EntityUtils.toString(re,"utf-8");
		}catch (Exception e) {
			LogUtils.error("HttpUtils.get error:" + response.getStatusLine()+",url=>"+url);
		}finally {
            if (null != client) {
                try {
                	client.close();
                } catch (IOException e) {
                	LogUtils.error("HttpUtils.get error!"+e.getMessage() );
                }
            }
        
		}
    	return null;
    }
    
    public static void main(String[] args) {
		System.out.println(post("http://127.0.0.1:1111/query/position",new JSONObject()));
	}
}