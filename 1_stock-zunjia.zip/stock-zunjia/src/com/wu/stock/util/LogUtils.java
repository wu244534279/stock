package com.wu.stock.util;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LogUtils {
	public static final Logger LOG = LogManager.getLogger(LogUtils.class);
	
	public static void debug(String msg) {
		LOG.debug(msg);
	}
	
	public static void info(String msg) {
		LOG.info(msg);
	}
	
	
	public static void error(String msg) {
		LOG.error(msg);
	}
	
	public static void main(String[] args) {
		debug("xxx");
	}
}
