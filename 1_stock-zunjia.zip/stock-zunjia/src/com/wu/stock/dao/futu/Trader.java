package com.wu.stock.dao.futu;

import com.wu.stock.entity.DealingOrder;
import com.wu.stock.futuapi.OrderApi;
import com.wu.stock.futuapi.TradeApi;

public class Trader {
	public static void buy(DealingOrder order) {
		TradeApi.buy(order);
	}
	
	public static void sell(DealingOrder order) {
		TradeApi.sell(order);
	}
	
	public static void cancel(DealingOrder order) {
		new OrderApi().cancelOrder(order);
	}
}
