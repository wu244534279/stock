package com.wu.stock.dao.zhunjia;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;

import com.wu.stock.config.MetaConfig;
import com.wu.stock.entity.Account;
import com.wu.stock.entity.BasicPrice;
import com.wu.stock.entity.DealingOrder;
import com.wu.stock.entity.MinutePrice;
import com.wu.stock.entity.StockPosition;
import com.wu.stock.futuapi.AccountApi;
import com.wu.stock.util.GeneralUtils;
import com.wu.stock.zhunjiaapi.ZJBasicPriceApi;
import com.wu.stock.zhunjiaapi.ZJMinutePriceApi;
import com.wu.stock.zhunjiaapi.ZJTradeApi;

public class DataGather {
	
	public static List<BasicPrice> getBasicPrices(){
		return ZJBasicPriceApi.getBasicPrices(MetaConfig.configMap.keySet());
	}
	
	public static BasicPrice getBasicPrice(String code){
		List<BasicPrice> basicPrices = ZJBasicPriceApi.getBasicPrices(Arrays.asList(code));
		if(GeneralUtils.isEmpty(basicPrices)) {
			return null;
		}
		return basicPrices.get(0);
	}
	
	public static void main(String[] args) {
		//BootStrap.initConfig();
		System.out.println(getBasicPrices());
		System.out.println(getMinutePrice("QCOM"));
	}
	
	
	public static MinutePrice getMinutePrice(String code){
		return ZJMinutePriceApi.getLastMinutePrices(code);
	}
	
	public static List<StockPosition> getPositions(){
		return ZJTradeApi.getPositions();
	}
	
	public static Map<String,StockPosition> getPositionsMap(){
		Map<String,StockPosition> map = new HashMap<String, StockPosition>();
		List<StockPosition> pos = getPositions();
		if (GeneralUtils.isEmpty(pos)) {
			return map;
		}
		for (StockPosition po:pos) {
			map.put(po.getCode(), po);
		}
		return map;
	}
	
	public static List<DealingOrder> getOrders(){
		return ZJTradeApi.getOrders();
	}
	
	public static Account getAccount() {
		return ZJTradeApi.getAccount();
	}
	
	public static boolean isTradeTime() {
		if (DateTime.now().withHourOfDay(21).withMinuteOfHour(32).isBeforeNow() || DateTime.now().withHourOfDay(3).withMinuteOfHour(55).isAfterNow()) {
			return true;
		}
		return false;
	}
	
	
}
