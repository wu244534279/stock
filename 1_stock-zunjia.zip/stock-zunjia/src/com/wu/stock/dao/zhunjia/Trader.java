package com.wu.stock.dao.zhunjia;

import com.wu.stock.entity.DealingOrder;
import com.wu.stock.zhunjiaapi.ZJTradeApi;

public class Trader {
	public static void buy(DealingOrder order) {
		ZJTradeApi.buy(order);
	}
	
	public static void sell(DealingOrder order) {
		ZJTradeApi.sell(order);
	}
	
	public static void cancel(DealingOrder order) {
		ZJTradeApi.cancel(order);
	}
}
