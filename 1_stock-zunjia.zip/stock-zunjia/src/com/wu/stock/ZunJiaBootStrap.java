package com.wu.stock;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.futu.openapi.FTAPI;
import com.wu.stock.config.MetaConfig;
import com.wu.stock.futuapi.ConnFactory;
import com.wu.stock.futuapi.TradFactory;
import com.wu.stock.thread.BuyThread;
import com.wu.stock.thread.OrderThread;
import com.wu.stock.thread.SellThread;
import com.wu.stock.util.LogUtils;
import com.wu.stock.zhunjiaapi.ZJBasicPriceApi;

public class ZunJiaBootStrap {
	public static final Logger LOG = LogManager.getLogger(ZunJiaBootStrap.class);
	public static void main(String[] args) {
		//FTAPI.init();
		initConfig();
		//ConnFactory.initConnect();
		//TradFactory.initConnect();
		new BuyThread().start();
		new SellThread().start();
		new OrderThread().start();
	}
	
	public static void initConfig() {
		BufferedReader br=null;
		try {
			br = new BufferedReader(new FileReader("config.txt"));
			String line = null;
			MetaConfig.configMap.clear();
			while ((line=br.readLine())!=null) {
				if (line.contains("code,")) {
					continue;
				}
				
				String[] config = line.split(",");
				MetaConfig cf = new MetaConfig(config[0].trim(), Double.parseDouble(config[1].trim()),
						Double.parseDouble(config[2].trim()), Double.parseDouble(config[3].trim()));
						MetaConfig.configMap.put(config[0].trim(), cf);
			}
			LOG.info("init config complete,config size="+MetaConfig.configMap.size());
		} catch (Exception e) {
			LOG.error("initConfig error!",e);
		}finally {
			try {
				br.close();
			} catch (IOException e) {
				LOG.error("initConfig close file error!",e);
			}
		}
		
	}
}
