package com.wu.stock.futuapi;

import java.util.LinkedList;
import java.util.List;

import com.futu.openapi.FTAPI_Conn;
import com.futu.openapi.FTSPI_Trd;
import com.futu.openapi.pb.TrdCommon;
import com.futu.openapi.pb.TrdCommon.Order;
import com.futu.openapi.pb.TrdGetOrderList;
import com.futu.openapi.pb.TrdModifyOrder;
import com.wu.stock.entity.DealingOrder;
import com.wu.stock.util.GeneralUtils;
import com.wu.stock.util.LogUtils;

public class OrderApi implements FTSPI_Trd {
    TradFactory tf;

    List<Order> orders;
    
    @Override
    public void onReply_GetOrderList(FTAPI_Conn client, int nSerialNo, TrdGetOrderList.Response rsp) {
    	if(rsp.getRetType()<0) {
    		LogUtils.error("OrderApi.onReply_GetOrderList error!"+rsp.getRetMsg());
    	}
    	orders = rsp.getS2C().getOrderListList();
    	tf.close();
    }

    public List<DealingOrder> getOrders(){
    	tf = TradFactory.getConnect();
        tf.trd.setTrdSpi(this);   //���ý��׻ص�
        
        TrdCommon.TrdHeader header = TrdCommon.TrdHeader.newBuilder()
                .setAccID(FutuConfig.ACC_ID)
                .setTrdEnv(FutuConfig.ENV)
                .setTrdMarket(FutuConfig.MARKET_TRAD)
                .build();
        TrdGetOrderList.C2S c2s = TrdGetOrderList.C2S.newBuilder()
                .setHeader(header)
            .build();
        TrdGetOrderList.Request req = TrdGetOrderList.Request.newBuilder().setC2S(c2s).build();
        int seqNo = tf.trd.getOrderList(req);

        List<DealingOrder> os = new LinkedList<DealingOrder>();
        
        if (seqNo == 0) {
        	LogUtils.error("OrderApi.getOrders error!");
        	return null;
        }
        while(orders==null) {
        	GeneralUtils.sleep(200);
        }
        for (Order order : orders) {
        	if(order.getOrderStatus()==TrdCommon.OrderStatus.OrderStatus_Submitted_VALUE || order.getOrderStatus()==TrdCommon.OrderStatus.OrderStatus_Filled_Part_VALUE) {
        		os.add(new DealingOrder(order.getOrderID(),order.getCode(), order.getPrice(), order.getQty(), order.getCreateTime()));
        	}
		}
        
        return os;
        
    }
    
    public void cancelOrder(DealingOrder order) {
    	tf = TradFactory.getConnect();
        tf.trd.setTrdSpi(this);   //���ý��׻ص�
    	TrdCommon.TrdHeader header = TrdCommon.TrdHeader.newBuilder()
                .setAccID(FutuConfig.ACC_ID)
                .setTrdEnv(FutuConfig.ENV)
                .setTrdMarket(FutuConfig.MARKET_TRAD)
                .build();
        TrdModifyOrder.C2S c2s = TrdModifyOrder.C2S.newBuilder()
                .setPacketID(tf.trd.nextPacketID())
                .setHeader(header)
                .setOrderID(order.getOrderId())
                .setModifyOrderOp(TrdCommon.ModifyOrderOp.ModifyOrderOp_Cancel_VALUE)
            .build();
        TrdModifyOrder.Request req = TrdModifyOrder.Request.newBuilder().setC2S(c2s).build();
        int seqNo = tf.trd.modifyOrder(req);
        if (seqNo == 0) {
        	LogUtils.error("OrderApi.cancelOrder error!");
        }
        while(!isCancel) {
        	GeneralUtils.sleep(200);
        }
        
    }
    
    private boolean isCancel;
    
    @Override
    public void onReply_ModifyOrder(FTAPI_Conn client, int nSerialNo, TrdModifyOrder.Response rsp) {
    	if(rsp.getRetType()<0) {
    		LogUtils.error("OrderApi.onReply_ModifyOrder error!"+rsp.getRetMsg());
    	}
        isCancel=true;
        tf.close();
    }
    
}
