package com.wu.stock.futuapi;

import java.util.LinkedList;
import java.util.List;

import com.futu.openapi.FTAPI_Conn;
import com.futu.openapi.FTSPI_Trd;
import com.futu.openapi.pb.TrdCommon;
import com.futu.openapi.pb.TrdCommon.Position;
import com.futu.openapi.pb.TrdGetPositionList;
import com.wu.stock.entity.StockPosition;
import com.wu.stock.util.GeneralUtils;
import com.wu.stock.util.LogUtils;

public class PositionApi implements FTSPI_Trd {
    TradFactory tf;

    List<Position> positionList;
    
    @Override
    public void onReply_GetPositionList(FTAPI_Conn client, int nSerialNo, TrdGetPositionList.Response rsp) {
    	if(rsp.getRetType()<0) {
    		LogUtils.error("PositionApi.onReply_GetPositionList error!"+rsp.getRetMsg());
    	}
    	positionList = rsp.getS2C().getPositionListList();
    	tf.close();
    }

    public List<StockPosition> getPositions(){
    	tf = TradFactory.getConnect();
        tf.trd.setTrdSpi(this);   //���ý��׻ص�
        
        TrdCommon.TrdHeader header = TrdCommon.TrdHeader.newBuilder()
                .setAccID(FutuConfig.ACC_ID)
                .setTrdEnv(FutuConfig.ENV)
                .setTrdMarket(FutuConfig.MARKET_TRAD)
                .build();
        TrdGetPositionList.C2S c2s = TrdGetPositionList.C2S.newBuilder()
                .setHeader(header)
            .build();
        TrdGetPositionList.Request req = TrdGetPositionList.Request.newBuilder().setC2S(c2s).build();

        List<StockPosition> sps = new LinkedList<StockPosition>();
        
        int seqNo = tf.trd.getPositionList(req);
        if (seqNo == 0) {
        	LogUtils.error("PositionApi.getPositions error!");
        	return null;
        }
        while(positionList==null) {
        	GeneralUtils.sleep(200);
        }
        for (Position position : positionList) {
			sps.add(new StockPosition(position.getCode(), position.getQty(), position.getCostPrice()));
		}
        
        return sps;
        
    }
    
    
}
