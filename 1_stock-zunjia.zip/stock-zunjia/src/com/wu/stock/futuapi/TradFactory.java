package com.wu.stock.futuapi;

import java.util.HashSet;
import java.util.Set;

import com.futu.openapi.FTAPI_Conn;
import com.futu.openapi.FTAPI_Conn_Trd;
import com.futu.openapi.FTSPI_Conn;
import com.futu.openapi.FTSPI_Trd;
import com.futu.openapi.pb.TrdCommon;
import com.futu.openapi.pb.TrdUnlockTrade;
import com.wu.stock.util.GeneralUtils;
import com.wu.stock.util.LogUtils;

public class TradFactory implements FTSPI_Trd, FTSPI_Conn {
    FTAPI_Conn_Trd trd = new FTAPI_Conn_Trd();
    private boolean isUsing;
    private boolean isInit;
    
    public TradFactory() {
        trd.setClientInfo("javaclient", 1);  //���ÿͻ�����Ϣ
        trd.setConnSpi(this);  //�������ӻص�
        trd.setTrdSpi(this);   //���ý��׻ص�
    }

    public void start() {
        trd.initConnect("127.0.0.1", (short)11111, false);
    }

    @Override
    public void onInitConnect(FTAPI_Conn client, long errCode, String desc)
    {
        System.out.printf("Trd onInitConnect: ret=%b desc=%s connID=%d\n", errCode, desc, client.getConnectID());
        if (errCode != 0)
            return;
        isInit=true;
    }
    
    @Override
    public void onReply_UnlockTrade(FTAPI_Conn client, int nSerialNo, TrdUnlockTrade.Response rsp) {
    	LogUtils.info("TradFactory Reply: TrdUnlockTrade: "+ rsp.getRetMsg());
    }

    
    public void unlockAccount() {
        TrdUnlockTrade.C2S c2s = TrdUnlockTrade.C2S.newBuilder()
        		.setPwdMD5("22e5dd7d8b610d4bc541b5aa5d10b5b6")
                .setUnlock(true)
                .setSecurityFirm(TrdCommon.SecurityFirm.SecurityFirm_FutuSecurities_VALUE)
                .build();
        TrdUnlockTrade.Request req = TrdUnlockTrade.Request.newBuilder().setC2S(c2s).build();
        int seqNo = trd.unlockTrade(req);
        if (seqNo == 0) {
        	LogUtils.error("TradFactory.unlockAccount error!");
        }
    }
    
    private static  Set<TradFactory> cons = new HashSet<>();

    public static void initConnect() {
    	for (int i=0;i<5;i++) {
    		TradFactory tradFactory = new TradFactory();
        	tradFactory.start();
        	while (!tradFactory.isInit) {
				GeneralUtils.sleep(100);
			}
        	if(i==0) {
        		tradFactory.unlockAccount();
        	}
        	cons.add(tradFactory);
		}

    }
    
    public static synchronized TradFactory getConnect() {
    	while(true) {
	    	for (TradFactory con : cons) {
				if(!con.isUsing) {
					con.isUsing=true;
					return con;
				}
			}
	    	GeneralUtils.sleep(100);
    	}
    }
    
    public void close() {
    	this.isUsing=false;
    }
}
