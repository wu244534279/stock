package com.wu.stock.futuapi;

import com.futu.openapi.pb.QotCommon;
import com.futu.openapi.pb.TrdCommon;

public class FutuConfig {
	
	public static final int ENV = TrdCommon.TrdEnv.TrdEnv_Simulate_VALUE;
	public static final int ACC_ID =5260081;
	public static final int ORDER_TYPE = TrdCommon.OrderType.OrderType_Normal_VALUE;
	public static final int MARKE_QOT=QotCommon.QotMarket.QotMarket_US_Security_VALUE;
	public static final int MARKET_TRAD = TrdCommon.TrdMarket.TrdMarket_US_VALUE;
}
