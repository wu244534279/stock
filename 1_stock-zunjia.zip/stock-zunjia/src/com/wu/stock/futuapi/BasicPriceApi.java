package com.wu.stock.futuapi;

import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import com.futu.openapi.FTAPI_Conn;
import com.futu.openapi.FTSPI_Qot;
import com.futu.openapi.pb.QotCommon;
import com.futu.openapi.pb.QotCommon.BasicQot;
import com.futu.openapi.pb.QotGetBasicQot;
import com.futu.openapi.pb.QotGetBasicQot.C2S.Builder;
import com.wu.stock.config.MetaConfig;
import com.wu.stock.entity.BasicPrice;
import com.wu.stock.util.GeneralUtils;
import com.wu.stock.util.LogUtils;

public class BasicPriceApi implements FTSPI_Qot {
    ConnFactory cf;

    private List<BasicQot> bqs;

    @Override
    public void onReply_GetBasicQot(FTAPI_Conn client, int nSerialNo, QotGetBasicQot.Response rsp) {
    	if(rsp.getRetType()<0) {
    		LogUtils.error("BasicPriceApi.onReply_GetBasicQot error!"+rsp.getRetMsg());
    	}
    	bqs = rsp.getS2C().getBasicQotListList();
    	cf.close();
    	
    }

    public List<BasicPrice> getAllBqs(){
    	cf = ConnFactory.getConnect();
        cf.qot.setQotSpi(this);   //���ý��׻ص�
        
        
        Builder newBuilder = QotGetBasicQot.C2S.newBuilder();
    	
    	Set<String> codes = MetaConfig.configMap.keySet();
    	for (String code : codes) {
        	QotCommon.Security sec = QotCommon.Security.newBuilder()
                    .setMarket(FutuConfig.MARKE_QOT)
                    .setCode(code)
                    .build();
        	newBuilder.addSecurityList(sec);
		}
        
        QotGetBasicQot.Request req = QotGetBasicQot.Request.newBuilder().setC2S(newBuilder.build()).build();
        int seqNo = cf.qot.getBasicQot(req);
        if (seqNo == 0) {
        	LogUtils.error("BasicPriceApi.getAllBqs error!");
        	return null;
        }
        while(bqs==null) {
        	GeneralUtils.sleep(200);
        }
        List<BasicPrice> bp = new LinkedList<BasicPrice>();
        for (BasicQot bq : bqs) {
			bp.add(new BasicPrice(bq.getSecurity().getCode(), bq.getCurPrice(), bq.getLastClosePrice()));
		}
    	return bp;
    }
    
    
    public BasicPrice getBqs(String code){
    	cf = ConnFactory.getConnect();
        cf.qot.setQotSpi(this);   //���ý��׻ص�
        
    	QotCommon.Security sec = QotCommon.Security.newBuilder()
                .setMarket(FutuConfig.MARKE_QOT)
                .setCode(code)
                .build();
        QotGetBasicQot.C2S c2s = QotGetBasicQot.C2S.newBuilder()
                .addSecurityList(sec)
                .build();
        QotGetBasicQot.Request req = QotGetBasicQot.Request.newBuilder().setC2S(c2s).build();
        int seqNo = cf.qot.getBasicQot(req);
        if (seqNo == 0) {
        	LogUtils.error("BasicPriceApi.getBqs error!");
        	return null;
        }
        while(bqs==null) {
        	GeneralUtils.sleep(200);
        }
    	
    	if(GeneralUtils.isEmpty(bqs)) {
    		return null;
    	}
    	BasicQot bq = bqs.get(0);
    	return new BasicPrice(bq.getSecurity().getCode(), bq.getCurPrice(), bq.getLastClosePrice());
    }
}
