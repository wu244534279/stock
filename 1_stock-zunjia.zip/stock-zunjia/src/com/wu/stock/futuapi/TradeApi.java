package com.wu.stock.futuapi;

import com.futu.openapi.FTAPI_Conn;
import com.futu.openapi.FTSPI_Conn;
import com.futu.openapi.FTSPI_Trd;
import com.futu.openapi.pb.TrdCommon;
import com.futu.openapi.pb.TrdCommon.TimeInForce;
import com.futu.openapi.pb.TrdCommon.TrdSecMarket;
import com.futu.openapi.pb.TrdCommon.TrdSide;
import com.futu.openapi.pb.TrdPlaceOrder;
import com.futu.openapi.pb.TrdPlaceOrder.Response;
import com.wu.stock.entity.DealingOrder;
import com.wu.stock.util.GeneralUtils;
import com.wu.stock.util.LogUtils;

public class TradeApi implements FTSPI_Trd,FTSPI_Conn{
	TradFactory tf;
	
    int trdSide;
    double  qty;
    String code;
    double price;
    public TradeApi(String code,double price,int trdSide,double qty) {
    	tf=TradFactory.getConnect();
    	tf.trd.setTrdSpi(this);  
    	this.trdSide = trdSide;
    	this.qty=qty;
    	this.code=code;
    	this.price=price;
    }

    public void start() {
    	TrdCommon.TrdHeader header = TrdCommon.TrdHeader.newBuilder()
                .setAccID(FutuConfig.ACC_ID)
                .setTrdEnv(FutuConfig.ENV)
                .setTrdMarket(FutuConfig.MARKET_TRAD)
                .build();
        TrdPlaceOrder.C2S c2s = TrdPlaceOrder.C2S.newBuilder()
                .setPacketID(tf.trd.nextPacketID())
                .setHeader(header)
                .setOrderType(FutuConfig.ORDER_TYPE)
                .setCode(code)
                .setQty(qty)
                .setTimeInForce(TimeInForce.TimeInForce_DAY_VALUE)
                .setPrice(price).setTrdSide(trdSide).setSecMarket(TrdSecMarket.TrdSecMarket_US_VALUE)
            .build();
        TrdPlaceOrder.Request req = TrdPlaceOrder.Request.newBuilder().setC2S(c2s).build();
        int seqNo = tf.trd.placeOrder(req);
        if (seqNo == 0) {
        	LogUtils.error("TradeApi.start error!");
        }
    }
    
    
    boolean isOrderPlaced;
    
    @Override
    public void onReply_PlaceOrder(FTAPI_Conn client, int nSerialNo, Response rsp) {
    	if (rsp.getRetType()<0) {
    		LogUtils.error("TradeApi.onReply_PlaceOrder:"+rsp.getRetMsg());
		}
    	isOrderPlaced=true;
    	tf.close();
    }
    
    public static void buy(DealingOrder order) {
        TradeApi tradeProcessor = new TradeApi(order.getCode(),order.getPrice(), TrdSide.TrdSide_Buy_VALUE,order.getQty());
		tradeProcessor.start();
        while (!tradeProcessor.isOrderPlaced) {
			GeneralUtils.sleep(100);
		}
    }
    
    public static void sell(DealingOrder order) {        
    	TradeApi tradeProcessor = new TradeApi(order.getCode(),order.getPrice(), TrdSide.TrdSide_Sell_VALUE,order.getQty());
		tradeProcessor.start();
	    while (!tradeProcessor.isOrderPlaced) {
			GeneralUtils.sleep(100);
	    }
	}
}

 