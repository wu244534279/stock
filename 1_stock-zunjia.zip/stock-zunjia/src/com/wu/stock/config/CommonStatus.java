package com.wu.stock.config;

import java.util.HashSet;
import java.util.Set;

public class CommonStatus {
	
	/**
	 * ����Ҫ����
	 */
	public volatile static Set<String> CODE_BUYING = new HashSet<>();
	
}
