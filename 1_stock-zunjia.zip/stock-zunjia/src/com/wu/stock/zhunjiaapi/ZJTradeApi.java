package com.wu.stock.zhunjiaapi;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.DateTimeFormatterBuilder;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.wu.stock.entity.Account;
import com.wu.stock.entity.DealingOrder;
import com.wu.stock.entity.StockPosition;
import com.wu.stock.util.GeneralUtils;
import com.wu.stock.util.HttpUtils;

public class ZJTradeApi {
	public static final Logger LOG = LogManager.getLogger(ZJTradeApi.class);
	private static final String URL_PREFIX="http://193.112.209.88:1112";
	
	public static List<StockPosition> getPositions(){
		JSONObject res = HttpUtils.post(URL_PREFIX+"/query/position",new JSONObject());
		if(res==null || res.size()==0) {
			return null;
		}
		JSONArray jsonArray = res.getJSONArray("positions");
		if(jsonArray==null || jsonArray.size()==0) {
			return null;
		}
		
		List<StockPosition> posList = new ArrayList<StockPosition>(jsonArray.size());
		for (int i = 0; i < jsonArray.size(); i++) {
			JSONObject jo = jsonArray.getJSONObject(i);
			double doubleValue = jo.getDoubleValue("total_qty");
			if(doubleValue<1) {
				continue;
			}
			posList.add(new StockPosition(jo.getString("symbol"), doubleValue, jo.getDoubleValue("cost_px")));
		}
		return posList;
		
	}
	
	private static final Collection<String> DEALING_ORDER_STATUS= Arrays.asList("PENDING","NEW","PARTIALLY_FILLED");
	
	public static List<DealingOrder> getOrders(){
		JSONObject res = HttpUtils.post(URL_PREFIX+"/query/order",new JSONObject());
		if(res==null || res.size()==0) {
			return null;
		}
		JSONArray jsonArray = res.getJSONArray("orders");
		if(jsonArray==null || jsonArray.size()==0) {
			return null;
		}
		
		List<DealingOrder> resList = new ArrayList<DealingOrder>(jsonArray.size());
		for (int i = 0; i < jsonArray.size(); i++) {
			JSONObject jo = jsonArray.getJSONObject(i);
			String status = jo.getString("status");
			if(!DEALING_ORDER_STATUS.contains(status)) {
				continue;
			}
			String createDate = jo.getString("insert_date");
			String createTime = jo.getString("insert_time");
			String dateTimeString = GeneralUtils.toDateTimeString(createDate, createTime);
			resList.add(new DealingOrder(jo.getString("order_id"), jo.getString("symbol"), jo.getDoubleValue("qty"), jo.getDoubleValue("price"), dateTimeString));
		}
		return resList;
	}
	
	public static Account getAccount() {
		return new Account("",10000);
	}
	
	
	public static void buy(DealingOrder order) {
		
		JSONObject param = new JSONObject();
		param.put("clord_id", System.currentTimeMillis()+"");
		param.put("exchange", "US");
		param.put("symbol", order.getCode());
		param.put("side", "BUY");
		param.put("price", order.getPrice());
		param.put("qty", order.getQty());
//		param.put("type", "Market");//�м�
		param.put("type", "Limit");//���Ի�����
		JSONObject res = HttpUtils.post(URL_PREFIX+"/order/insert",param);
		
		LOG.info("************buy order "+order+"--result="+res.toJSONString());
	}
	public static void sell(DealingOrder order) {
		
		JSONObject param = new JSONObject();
		param.put("clord_id", System.currentTimeMillis()+"");
		param.put("exchange", "US");
		param.put("symbol", order.getCode());
		param.put("side", "SELL");
		param.put("price", order.getPrice());
		param.put("qty", order.getQty());
//		param.put("type", "Market");//�м�
		param.put("type", "Limit");//���Ի�����
		JSONObject res = HttpUtils.post(URL_PREFIX+"/order/insert",param);
		
		LOG.info("************sell order "+order+"--result="+res.toJSONString());
	}
	
	public static void cancel(DealingOrder order) {
		LOG.info("----------cancel order "+order);
		JSONObject param = new JSONObject();
		param.put("order_id", order.getOrderIdStr());
		JSONObject res = HttpUtils.post(URL_PREFIX+"/order/cancel",param);
		LOG.info("************cancel order "+order+"--result="+res.toJSONString());
	}
	
	public static void main(String[] args) {
		System.out.println(getOrders());
	}
}
