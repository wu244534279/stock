package com.wu.stock.zhunjiaapi;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.alibaba.fastjson.JSONObject;
import com.wu.stock.entity.BasicPrice;
import com.wu.stock.entity.MinutePrice;
import com.wu.stock.util.GeneralUtils;
import com.wu.stock.util.HttpUtils;

public class ZJMinutePriceApi {
	private static Random random = new Random();
	public static final Logger LOG = LogManager.getLogger(ZJMinutePriceApi.class);
	
	public static MinutePrice getLastMinutePrices(String code){
		GeneralUtils.sleep(random.nextInt(1000));
		String url ="http://stock.finance.sina.com.cn/usstock/api/openapi.php/US_MinlineNService.getMinline?day=1&symbol="+code.toLowerCase()+"&t="+System.currentTimeMillis();
		String res = HttpUtils.get(url);
		if (res.length()<50) {
			return null;
		}
		String[] split = res.split(";");
		String[] lastStr = split[split.length-1].split("\"}}")[0].split(",");
		
		try {
			MinutePrice minutePrice = new MinutePrice(code, lastStr[3], lastStr[2], lastStr[0]);
			LOG.debug(minutePrice);
			return minutePrice;
		} catch (Exception e) {
			LOG.error("getLastMinutePrices error,code="+code+"---"+res);
			return null;
		}
		
	}
	
	
	public static void main(String[] args) {
		System.out.println(getLastMinutePrices("AAPL"));
	}
	
}
