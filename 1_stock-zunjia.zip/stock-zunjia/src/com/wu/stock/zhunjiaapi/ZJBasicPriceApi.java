package com.wu.stock.zhunjiaapi;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Random;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.wu.stock.entity.BasicPrice;
import com.wu.stock.util.GeneralUtils;
import com.wu.stock.util.HttpUtils;
import com.wu.stock.util.LogUtils;

public class ZJBasicPriceApi {
	public static final Logger LOG = LogManager.getLogger(ZJBasicPriceApi.class);
	private static Random random = new Random();
	public static List<BasicPrice> getBasicPrices(Collection<String> codes){
		GeneralUtils.sleep(random.nextInt(1000));
		StringBuilder sb = new StringBuilder("http://hq.sinajs.cn/?rn=1617072612960&list=");
		for (String code : codes) {
			sb.append("gb_").append(code.toLowerCase()).append(",");
		}
		String res = HttpUtils.get(sb.toString());
		String[] split = res.split("\n");
		List<BasicPrice> prices = new ArrayList<BasicPrice>(split.length+1);
		for (String line : split) {
			if(GeneralUtils.isEmpty(line) || line.length()<14) {
				continue;
			}
			String code = line.substring(14, line.indexOf("="));
			double curPrice = Double.parseDouble(line.split(",")[1].trim());
			prices.add(new BasicPrice(code.toUpperCase(),curPrice,0d));
		}
		return prices;
	}
	
	
	public static void main(String[] args) {
		System.out.println(getBasicPrices(Arrays.asList("AAPL","BIDU")));
	}
	
}
