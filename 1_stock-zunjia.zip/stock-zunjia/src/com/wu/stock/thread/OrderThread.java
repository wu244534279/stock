package com.wu.stock.thread;

import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.wu.stock.dao.zhunjia.DataGather;
import com.wu.stock.dao.zhunjia.Trader;
import com.wu.stock.entity.DealingOrder;
import com.wu.stock.util.GeneralUtils;
import com.wu.stock.util.LogUtils;

public class OrderThread extends Thread{
	public static final int ORDER_EXPIRE_MINUTES = 3;
	public static final Logger LOG = LogManager.getLogger(OrderThread.class);
	@Override
	public void run() {
		while(true) {
			try {
				LOG.debug("OrderThread running....!"+new Date());
				if(!DataGather.isTradeTime()) {
					LOG.info("OrderThread current time is not trade time!"+new Date());
					GeneralUtils.sleep(60000);
					continue;
				}
				
				List<DealingOrder> orders = DataGather.getOrders();
				if(GeneralUtils.isEmpty(orders)) {
					LOG.info("OrderThread running,no dealing orders");
					GeneralUtils.sleep(60000);
					continue;
				}
				
				for (DealingOrder order : orders) {
					if(expire(order)) {
						LOG.info("--------OrderThread order is expire,will cancel it==>"+order);
						Trader.cancel(order);
					}else {
						LOG.debug("OrderThread order is not expire==>"+order);
					}
				}
			} catch (Exception e) {
				LOG.error("OrderThread error",e);
			}
				
		}
	}

	private boolean expire(DealingOrder order) {

		long cts = GeneralUtils.toLong(order.getCreateTime())+12*60*60*1000;
		long minutesDif = (System.currentTimeMillis() - cts) / (1000 * 60);
		if (minutesDif>1) {
			LOG.info("cancel time out order! --"+order);
			return true;
		}
	
		return false;
	}
	
}
