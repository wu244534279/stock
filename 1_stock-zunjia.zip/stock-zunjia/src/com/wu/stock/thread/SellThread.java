package com.wu.stock.thread;

import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.wu.stock.config.MetaConfig;
import com.wu.stock.dao.zhunjia.DataGather;
import com.wu.stock.dao.zhunjia.Trader;
import com.wu.stock.entity.BasicPrice;
import com.wu.stock.entity.DealingOrder;
import com.wu.stock.entity.StockPosition;
import com.wu.stock.util.GeneralUtils;

public class SellThread extends Thread{
	
	public static final Logger LOG = LogManager.getLogger(SellThread.class);
	@Override
	public void run() {
		while(true) {
			
			try {
				LOG.debug("SellThread running....!"+new Date());
				if(!DataGather.isTradeTime()) {
					LOG.info("SellThread current time is not sell time!"+new Date());
					GeneralUtils.sleep(60000);
					continue;
				}
				
				List<StockPosition> positions = DataGather.getPositions();
				if(GeneralUtils.isEmpty(positions)) {
					LOG.info("SellThread running,no positions");
					GeneralUtils.sleep(60000);
					continue;
				}
				
				List<DealingOrder> orders = DataGather.getOrders();
				
				for (StockPosition pos : positions) {
					if (pos.getQty()<=0) {
						LOG.debug("The pos's qty is zero!"+pos);
						continue;
					}
					
					if(posOnOrdering(pos,orders)) {
						LOG.debug("The pos is in ordering,will not sell again!"+pos.getCode());
						continue;
					}
					
					BasicPrice basicPrice = DataGather.getBasicPrice(pos.getCode());
					if(basicPrice==null) {
						LOG.error("SellThread running,get basicPrice error!"+pos.getCode());
						continue;
					}
					
					MetaConfig config = MetaConfig.getConfig(pos.getCode());
					LOG.info("SellThread  pos:"+pos+"-cur price=>"+basicPrice.getCurPrice());
					if(basicPrice.getCurPrice()>= (pos.getCostPrice()*(1.0d+config.getSellPointCostHight()))) {
						DealingOrder order= new DealingOrder(pos.getCode(),basicPrice.getCurPrice(),pos.getQty(),null);
						Trader.sell(order);
					}
					
				}
				
				GeneralUtils.sleep(200);
			} catch (Exception e) {
				LOG.error("SellThread error",e);
			}
		}
	}

	private boolean posOnOrdering(StockPosition pos, List<DealingOrder> orders) {
		if(GeneralUtils.isEmpty(orders)) {
			return false;
		}
		
		for (DealingOrder dealingOrder : orders) {
			if(dealingOrder.getCode().equals(pos.getCode())) {
				return true;
			}
		}
		return false;
	}
}
