package com.wu.stock.entity;

/**
 * ��ʱ����
 * @author Administrator
 *
 */
public class MinutePrice {
	private  String code;
	private double curPrice;
	private double avgPrice;
	private String time;
	
	public MinutePrice(String code, double curPrice, double avgPrice,String time) {
		super();
		this.code = code;
		this.curPrice = curPrice;
		this.avgPrice = avgPrice;
		this.time=time;
	}
	public MinutePrice(String code, String curPrice, String avgPrice, String time) {
		this(code,Double.parseDouble(curPrice.trim()),Double.parseDouble(avgPrice.trim()),time);
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public double getCurPrice() {
		return curPrice;
	}
	public void setCurPrice(double curPrice) {
		this.curPrice = curPrice;
	}
	public double getAvgPrice() {
		return avgPrice;
	}
	public void setAvgPrice(double avgPrice) {
		this.avgPrice = avgPrice;
	}
	@Override
	public String toString() {
		return "MinutePrice [code=" + code + ", curPrice=" + curPrice + ", avgPrice=" + avgPrice + ", time=" + time
				+ "]";
	}

	
}
