package com.wu.stock.entity;

import java.util.Date;

/**
 * ����
 * @author Administrator
 *
 */
public class DealingOrder {
	private long orderId;
	private String orderIdStr;
	private String code;
	private double price;
	private double qty;
	private String createTime;
	
	public DealingOrder(long orderId,String code, double price, double qty, String createTime) {
		super();
		this.orderId=orderId;
		this.code = code;
		this.price = price;
		this.qty = qty;
		this.createTime = createTime;
	}
	
	public DealingOrder(String orderIdStr,String code, double price, double qty, String createTime) {
		super();
		this.orderIdStr=orderIdStr;
		this.code = code;
		this.price = price;
		this.qty = qty;
		this.createTime = createTime;
	}
	
	public DealingOrder(String code, double price, double qty, String createTime) {
		super();
		this.code = code;
		this.price = price;
		this.qty = qty;
		this.createTime = createTime;
	}
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getQty() {
		return qty;
	}
	public void setQty(double qty) {
		this.qty = qty;
	}

	
	public long getOrderId() {
		return orderId;
	}

	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getOrderIdStr() {
		return orderIdStr;
	}

	public void setOrderIdStr(String orderIdStr) {
		this.orderIdStr = orderIdStr;
	}

	@Override
	public String toString() {
		return "Order [code=" + code + ", price=" + price + ", qty=" + qty + ", createTime=" + createTime + "]";
	}
	
	
}
